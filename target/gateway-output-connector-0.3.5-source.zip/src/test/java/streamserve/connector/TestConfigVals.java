package streamserve.connector;

public class TestConfigVals extends StrsConfigVals {
	private static final long serialVersionUID = -7717996614048822106L;

	public TestConfigVals(){
		super();
	}
	
	public void setSystemValue(String keyName, String value){
		 super.setSystemValue(keyName, value);
	 }
}
